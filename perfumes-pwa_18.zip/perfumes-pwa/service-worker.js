// Cache do "app shell" para abrir offline.
//
// Estratégia por tipo de requisição:
//  - documento HTML (navegação): REDE PRIMEIRO. Assim, uma versão nova do
//    arquivo é usada assim que existe conexão, sem ficar presa no cache.
//    Se a rede falhar, cai para o cache e o app abre offline normalmente.
//  - demais arquivos do próprio domínio (ícones, manifest): cache primeiro,
//    com atualização em segundo plano.
//  - chamadas externas (clima/geocodificação/API): nunca interceptadas.
const CACHE = 'perfumes-shell-v55';
const SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-192-maskable.png',
  './icons/icon-512-maskable.png',
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);

  // Deixa passar direto para a rede: APIs externas (clima, Anthropic, imagens
  // de lojas). Cachear isso não faz sentido e atrapalharia.
  if(url.origin !== self.location.origin) return;

  const ehDocumento = req.mode === 'navigate' ||
                      (req.destination === 'document') ||
                      (req.headers.get('accept') || '').includes('text/html');

  if(ehDocumento){
    // REDE PRIMEIRO — garante que uma versão nova do app seja usada de imediato.
    event.respondWith(
      fetch(req).then(res => {
        if(res && res.ok){
          const clone = res.clone();
          caches.open(CACHE).then(cache => cache.put(req, clone));
        }
        return res;
      }).catch(() => caches.match(req).then(c => c || caches.match('./index.html')))
    );
    return;
  }

  // Demais arquivos locais: cache primeiro, atualizando por trás.
  event.respondWith(
    caches.match(req).then(cached => {
      const rede = fetch(req).then(res => {
        if(res && res.ok){
          const clone = res.clone();
          caches.open(CACHE).then(cache => cache.put(req, clone));
        }
        return res;
      }).catch(() => cached);
      return cached || rede;
    })
  );
});
